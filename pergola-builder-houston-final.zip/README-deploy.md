# Pergola Builder Houston Deployment Guide

This site is built with Next.js + TailwindCSS and is already optimized for:
- Mobile
- SEO (titles, meta, sitemap.xml, robots.txt)
- Local pages (Houston / Katy / etc.)
- Fast load
- Lead capture

It also includes:
- Hero background video (autoplay, muted, loop)
- Floating mobile Call / Get Quote bar
- FAQ accordion
- Gallery with tap-to-zoom lightbox
- Google Analytics placeholder
- Google Search Console placeholder
- Footer credit linking to Get Local Maps

---
## 1. Put this code on GitHub

1. Go to https://github.com/new (make sure you're logged in as getlocalmaps@gmail.com or the account you created).
2. Repository name: `pergola-builder-houston`
3. Leave everything else default, click **Create repository**.
4. On the next screen, click **"uploading an existing file"**.
5. Drag and drop ALL the files from this folder into GitHub (or upload the .zip and let GitHub unpack).
6. Scroll down and click **Commit changes**.

Now your code lives in GitHub.

---
## 2. Deploy on Vercel

1. Go to https://vercel.com and log in.
2. Click **Add New → Project**.
3. Click **Continue with GitHub**.
4. Pick the `pergola-builder-houston` repo.
5. Click **Deploy**.

Vercel will build the site and then show you a live link like:
https://pergolabuilder.vercel.app

That is your staging site.

---
## 3. Connect your real domain

1. In Vercel, open your new project.
2. Go to **Settings → Domains**.
3. Click **Add Domain**.
4. Enter: `pergolabuilderhouston.com`
5. Vercel will show DNS records.
6. Go to your domain registrar (where you bought pergolabuilderhouston.com).
7. Paste those DNS records.
8. Save.

In a little bit, pergolabuilderhouston.com will point to your new site.

---
## 4. Turn on Google Analytics (GA4)

1. Visit https://analytics.google.com and log in with getlocalmaps@gmail.com.
2. Create a property called "Pergola Builder Houston".
3. Copy the GA4 Measurement ID (looks like: G-XXXXXXXXXX).
4. In `app/layout.tsx`, replace BOTH places where it says `G-XXXXXXXXXX` with your real ID.
5. Commit that change to GitHub. Vercel will auto-redeploy.

Now Analytics will track visitors.

---
## 5. Verify Search Console

1. Visit https://search.google.com/search-console and log in with getlocalmaps@gmail.com.
2. Click **Add Property** → choose Domain → `pergolabuilderhouston.com`
3. Google will check for the `<meta name="google-site-verification"...>` tag that is already in `app/layout.tsx`.
4. You should get "Verified".

Now you can see keywords, indexing, etc.

---
## 6. Update the quote form to send you leads

1. Go to https://formspree.io and create a form with `chavezdarrel@yahoo.com`.
2. Formspree will give you an "action" URL like: `https://formspree.io/f/abc12345`.
3. Open `app/components/ContactSection.tsx`
4. Replace `https://formspree.io/f/your-form-id` with your real URL.
5. Commit the change to GitHub. Vercel will update automatically.

Leads will start emailing you.

---
You're done. 💪
