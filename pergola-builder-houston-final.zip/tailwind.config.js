module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        brandBlue: "#2A5FFF",
        brandRed: "#B71C1C"
      },
      boxShadow: {
        card: "0 10px 30px -5px rgba(0,0,0,0.2)"
      },
      borderRadius: {
        xl: "1rem",
        "2xl": "1.5rem"
      }
    }
  },
  plugins: []
};
