import ContactSection from "../components/ContactSection";

export default function ContactPage() {
  return (
    <>
      <section className="section-wrapper pt-8 pb-4">
        <h1 className="text-3xl font-bold text-gray-900 text-center mb-4">
          Contact Pergola Builder Houston
        </h1>
        <p className="text-center text-gray-700 max-w-2xl mx-auto leading-relaxed">
          Your Local Pergola Experts in Houston, TX
        </p>
      </section>
      <ContactSection />
    </>
  );
}
