export default function BlogPage() {
  const posts: { title: string; excerpt: string; slug: string }[] = [];

  return (
    <section className="section-wrapper">
      <h1 className="text-3xl font-bold text-gray-900 text-center mb-4">
        Outdoor Living Tips & Inspiration
      </h1>
      <p className="text-center text-gray-700 max-w-2xl mx-auto leading-relaxed mb-12">
        Ideas for pergolas, patio covers, and outdoor kitchens in Houston, TX.
        Check back soon for guides, design inspo, and cost breakdowns.
      </p>

      {posts.length === 0 && (
        <div className="text-center text-gray-500 text-sm">
          No posts yet. Content coming soon.
        </div>
      )}
    </section>
  );
}
