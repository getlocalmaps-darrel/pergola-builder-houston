export default function CityPage() {
  const city = "Houston";
  const phone = "(832) 509-5457";

  return (
    <section className="section-wrapper">
      <h1 className="text-3xl font-bold text-gray-900 text-center mb-4">
        Pergola & Patio Cover Builders in Houston, TX
      </h1>
      <p className="text-center text-gray-700 max-w-2xl mx-auto leading-relaxed mb-12">
        Custom pergolas, patio covers, and outdoor kitchens built by Pergola Builder Houston.
        We design and build outdoor living spaces made for Texas weather.
      </p>

      <div className="space-y-12 max-w-4xl mx-auto">
        <div className="card">
          <h2 className="text-xl font-bold mb-2 text-gray-900">
            Pergolas in Houston, TX
          </h2>
          <p className="text-gray-700 text-sm leading-relaxed">
            Add shade and style to your backyard with a custom-built pergola.
            We use quality materials and build to match your home — not a
            big-box-store kit.
          </p>
        </div>

        <div className="card">
          <h2 className="text-xl font-bold mb-2 text-gray-900">
            Patio Covers in Houston, TX
          </h2>
          <p className="text-gray-700 text-sm leading-relaxed">
            Stay cool and protected from rain. Our patio covers extend your
            outdoor living area and look like they’ve always been part of
            your house.
          </p>
        </div>

        <div className="card">
          <h2 className="text-xl font-bold mb-2 text-gray-900">
            Outdoor Kitchens in Houston, TX
          </h2>
          <p className="text-gray-700 text-sm leading-relaxed">
            Full outdoor kitchen design and build: counters, grill station,
            storage, lighting, and more — perfect for hosting.
          </p>
        </div>
      </div>

      <div className="text-center mt-16">
        <a
          href="tel:+18325095457"
          className="cta-button bg-brandRed text-lg font-bold text-white"
        >
          Call {phone}
        </a>
      </div>
    </section>
  );
}
