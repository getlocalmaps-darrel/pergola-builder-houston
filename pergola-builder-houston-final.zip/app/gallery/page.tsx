import LightboxImage from "../components/LightboxImage";

export default function GalleryPage() {
  const images = [
    { src: "/gallery1.jpg", alt: "Pergola build" },
    { src: "/gallery2.jpg", alt: "Patio cover project" },
    { src: "/gallery3.jpg", alt: "Outdoor kitchen" },
    { src: "/gallery4.jpg", alt: "Shade structure" }
  ];

  return (
    <section className="section-wrapper">
      <h1 className="text-3xl font-bold text-center text-gray-900 mb-12">
        Project Gallery
      </h1>
      <div className="grid gap-4 md:grid-cols-3">
        {images.map((img, i) => (
          <LightboxImage key={i} {...img} />
        ))}
      </div>
    </section>
  );
}
