export default function ContactSection() {
  return (
    <section className="section-wrapper" id="quote">
      <h3 className="section-title">Get a Free Estimate</h3>
      <p className="text-center text-gray-700 max-w-xl mx-auto mb-8 leading-relaxed">
        Ready to build your outdoor space? Call us or send a request below.
      </p>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {/* Contact Info */}
        <div className="card text-center md:text-left">
          <div className="text-gray-900 font-bold text-lg">
            Pergola Builder Houston
          </div>
          <div className="text-gray-700 mt-2">
            Your Local Pergola Experts in Houston, TX
          </div>
          <a
            href="tel:+18325095457"
            className="block mt-4 text-gray-900 font-semibold text-lg"
          >
            (832) 509-5457
          </a>
          <a
            href="mailto:chavezdarrel@yahoo.com"
            className="block text-brandBlue font-medium mt-2"
          >
            chavezdarrel@yahoo.com
          </a>
        </div>

        {/* Quote Form */}
        <form
          className="card space-y-4"
          action="https://formspree.io/f/your-form-id"
          method="POST"
        >
          <input
            className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm"
            name="name"
            placeholder="Your Name"
            required
          />
          <input
            className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm"
            name="phone"
            placeholder="Phone Number"
            required
          />
          <input
            className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm"
            name="city"
            placeholder="City / Area"
          />
          <textarea
            className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm min-h-[100px]"
            name="project"
            placeholder="Tell us what you want to build (pergola, patio cover, outdoor kitchen, etc.)"
          />
          <button className="w-full bg-brandRed text-white font-semibold px-4 py-3 rounded-xl shadow-card hover:brightness-110">
            Send Request
          </button>
        </form>
      </div>
    </section>
  );
}
