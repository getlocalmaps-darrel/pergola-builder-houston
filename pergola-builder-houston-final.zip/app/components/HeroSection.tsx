import Image from "next/image";

export default function HeroSection() {
  return (
    <section className="relative text-white bg-black">
      {/* Background video */}
      <video
        className="absolute inset-0 w-full h-full object-cover opacity-40"
        autoPlay
        muted
        loop
        playsInline
        poster="/fallback.jpg"
      >
        <source src="/hero.mp4" type="video/mp4" />
      </video>
      {/* dark overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/80" />

      <div className="section-wrapper text-center relative z-10">
        <h1 className="text-3xl md:text-5xl font-bold max-w-3xl mx-auto text-white">
          Pergola Builder Houston – Custom Patio Covers, Pergolas & Outdoor Kitchens
        </h1>
        <p className="text-lg md:text-xl text-gray-200 mt-4 max-w-2xl mx-auto">
          Your Local Pergola Experts in Houston, TX
        </p>

        <div className="flex flex-col sm:flex-row gap-4 mt-8 justify-center">
          <a
            href="tel:+18325095457"
            className="cta-button bg-brandRed text-white"
          >
            Call (832) 509-5457
          </a>
          <a
            href="#quote"
            className="cta-button bg-brandBlue text-white"
          >
            Get a Free Quote
          </a>
        </div>
      </div>
    </section>
  );
}
