"use client";
import Image from "next/image";
import { useState } from "react";

export default function LightboxImage({ src, alt }: { src: string; alt: string }) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="block w-full overflow-hidden rounded-xl shadow-card bg-white"
      >
        <Image
          src={src}
          alt={alt}
          width={600}
          height={400}
          className="w-full h-48 md:h-56 object-cover"
        />
      </button>

      {open && (
        <div
          onClick={() => setOpen(false)}
          className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4"
        >
          <Image
            src={src}
            alt={alt}
            width={1200}
            height={800}
            className="max-h-[80vh] w-auto rounded-xl shadow-card"
          />
        </div>
      )}
    </>
  );
}
