export default function AboutSection() {
  return (
    <section className="bg-gray-50">
      <div className="section-wrapper">
        <h3 className="section-title">About Pergola Builder Houston</h3>
        <p className="text-gray-700 max-w-3xl mx-auto text-center leading-relaxed">
          We design and build custom outdoor living spaces built for Houston
          weather. From shade structures to full outdoor kitchens, everything
          we build is made to look like it was always part of your home. We
          handle design, materials, permits, and construction — start to
          finish.
        </p>
      </div>
    </section>
  );
}
