export default function CityFooter() {
  return (
    <footer className="bg-gray-900 text-gray-100 text-center px-6 py-12 mt-16">
      <h3 className="text-xl font-semibold mb-4">
        Serving Greater Houston and Nearby Cities
      </h3>
      <p className="max-w-2xl mx-auto text-gray-300 leading-relaxed">
        <a href="/service-areas/houston" className="hover:underline">Houston</a>{" | "}
        <a href="/service-areas/katy" className="hover:underline">Katy</a>{" | "}
        <a href="/service-areas/richmond" className="hover:underline">Richmond</a>{" | "}
        <a href="/service-areas/bellaire" className="hover:underline">Bellaire</a>{" | "}
        <a href="/service-areas/cypress" className="hover:underline">Cypress</a>{" | "}
        <a href="/service-areas/sugar-land" className="hover:underline">Sugar Land</a>{" | "}
        <a href="/service-areas/the-woodlands" className="hover:underline">The Woodlands</a>{" | "}
        <a href="/service-areas/spring" className="hover:underline">Spring</a>{" | "}
        <a href="/service-areas/pearland" className="hover:underline">Pearland</a>
      </p>
      <p className="mt-6 text-sm text-gray-400">
        © 2025 Pergola Builder Houston. All Rights Reserved.
      </p>
      <p className="text-sm text-gray-500">
        Website by <a href="https://www.getlocalmaps.com" target="_blank" className="underline">Get Local Maps</a>
      </p>
    </footer>
  );
}
