export default function ServicesSection() {
  return (
    <section className="section-wrapper">
      <h3 className="section-title">Our Outdoor Living Services</h3>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="card">
          <h2 className="text-xl font-bold mb-2 text-gray-900">Patio Covers</h2>
          <p className="text-gray-700 text-sm leading-relaxed">
            Enhance your backyard with a custom patio cover built to handle
            Houston heat and sudden rain. Stay cool, dry, and comfortable
            year-round.
          </p>
        </div>

        <div className="card">
          <h2 className="text-xl font-bold mb-2 text-gray-900">Pergolas</h2>
          <p className="text-gray-700 text-sm leading-relaxed">
            Hand-built pergolas designed for shade, style, and long-term
            durability. We build to match your home’s look — not a kit from
            the store.
          </p>
        </div>

        <div className="card">
          <h2 className="text-xl font-bold mb-2 text-gray-900">
            Outdoor Kitchens
          </h2>
          <p className="text-gray-700 text-sm leading-relaxed">
            Full outdoor kitchen design and construction: stonework, counters,
            grill stations, sinks, lighting, and more. Host like a pro.
          </p>
        </div>
      </div>
    </section>
  );
}
