"use client";
import { useState } from "react";
import Image from "next/image";
import clsx from "clsx";

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-brandBlue text-white shadow-card">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-4 py-3 md:py-4">
        {/* Logo / Brand */}
        <div className="flex items-center gap-2">
          <Image
            src="/logo.png"
            alt="Pergola Builder Houston"
            width={40}
            height={40}
            className="rounded"
          />
          <div className="leading-tight">
            <div className="text-sm font-bold md:text-base">
              Pergola Builder Houston
            </div>
            <div className="text-[11px] md:text-xs opacity-90">
              Your Local Pergola Experts in Houston, TX
            </div>
          </div>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <a href="/" className="hover:underline">Home</a>
          <a href="/services" className="hover:underline">Services</a>
          <a href="/gallery" className="hover:underline">Gallery</a>
          <a href="/contact" className="hover:underline">Contact</a>
          <a
            href="/contact#quote"
            className="bg-brandRed text-white px-4 py-2 rounded-xl shadow-card hover:brightness-110"
          >
            Get a Free Quote
          </a>
          <a href="tel:+18325095457" className="font-bold whitespace-nowrap">
            (832) 509-5457
          </a>
        </nav>

        {/* Mobile hamburger */}
        <button
          className="md:hidden text-white"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          <div className="w-6 h-[2px] bg-white mb-1" />
          <div className="w-6 h-[2px] bg-white mb-1" />
          <div className="w-6 h-[2px] bg-white" />
        </button>
      </div>

      {/* Mobile dropdown */}
      <div
        className={clsx(
          "md:hidden bg-brandBlue/95 text-white px-6 pb-6 space-y-4 transition-all origin-top",
          open ? "block" : "hidden"
        )}
      >
        <a href="/" className="block text-lg font-medium">Home</a>
        <a href="/services" className="block text-lg font-medium">Services</a>
        <a href="/gallery" className="block text-lg font-medium">Gallery</a>
        <a href="/contact" className="block text-lg font-medium">Contact</a>
        <a
          href="/contact#quote"
          className="block bg-brandRed text-white text-center px-4 py-3 rounded-xl shadow-card font-semibold"
        >
          Get a Free Quote
        </a>
        <a href="tel:+18325095457" className="block font-bold text-lg">
          (832) 509-5457
        </a>
      </div>
    </header>
  );
}
