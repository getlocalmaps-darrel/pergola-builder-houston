"use client";
export default function MobileCTA() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 flex md:hidden bg-white border-t border-gray-200 shadow-card">
      <a
        href="tel:+18325095457"
        className="w-1/2 text-center py-3 font-semibold text-gray-900"
      >
        Call Now
      </a>
      <a
        href="/contact#quote"
        className="w-1/2 text-center py-3 font-semibold text-white bg-brandRed"
      >
        Get Quote
      </a>
    </div>
  );
}
