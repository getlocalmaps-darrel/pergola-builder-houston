import LightboxImage from "./LightboxImage";

export default function GalleryPreview() {
  const images = [
    { src: "/gallery1.jpg", alt: "Pergola build" },
    { src: "/gallery2.jpg", alt: "Patio cover" },
    { src: "/gallery3.jpg", alt: "Outdoor kitchen" },
  ];
  return (
    <section className="section-wrapper">
      <h3 className="section-title">Recent Projects</h3>
      <div className="grid gap-4 md:grid-cols-3">
        {images.map((img, i) => (
          <LightboxImage key={i} {...img} />
        ))}
      </div>
    </section>
  );
}
