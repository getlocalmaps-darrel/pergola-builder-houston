"use client";
import { useState } from "react";

const faqs = [
  {
    q: "What materials do you use for pergolas?",
    a: "We use high-quality cedar, redwood, and pressure-treated lumber — chosen for durability and appearance in Houston weather."
  },
  {
    q: "Do you handle permits and HOA approvals?",
    a: "Yes. We manage permits, codes, and HOA approvals so your project is compliant and stress-free."
  },
  {
    q: "How long does installation take?",
    a: "Most pergolas and patio covers are completed in about 1–2 weeks depending on size, design, and weather."
  },
  {
    q: "Do you offer free estimates?",
    a: "Yes. Call (832) 509-5457 or submit the quote form and we’ll schedule a free, no-obligation estimate."
  }
];

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="bg-gray-50">
      <div className="section-wrapper max-w-3xl">
        <h3 className="section-title">Frequently Asked Questions</h3>
        <div className="space-y-4">
          {faqs.map((item, idx) => (
            <div key={idx} className="bg-white rounded-xl shadow-card p-4">
              <button
                className="w-full text-left flex justify-between items-center font-semibold text-gray-900"
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
              >
                <span>{item.q}</span>
                <span className="text-brandBlue text-xl leading-none">
                  {openIndex === idx ? "−" : "+"}
                </span>
              </button>
              {openIndex === idx && (
                <p className="text-gray-700 mt-3 text-sm leading-relaxed">
                  {item.a}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
