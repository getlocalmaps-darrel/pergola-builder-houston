import HeroSection from "./components/HeroSection";
import ServicesSection from "./components/ServicesSection";
import AboutSection from "./components/AboutSection";
import GalleryPreview from "./components/GalleryPreview";
import FAQSection from "./components/FAQSection";
import ContactSection from "./components/ContactSection";

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <ServicesSection />
      <AboutSection />
      <GalleryPreview />
      <FAQSection />
      <ContactSection />
    </>
  );
}
