export default function ServicesPage() {
  return (
    <section className="section-wrapper">
      <h1 className="text-3xl font-bold text-gray-900 text-center mb-12">
        Outdoor Living Services in Houston, TX
      </h1>

      <div className="space-y-12 max-w-4xl mx-auto">
        <div className="card">
          <h2 className="text-xl font-bold mb-2 text-gray-900">Patio Covers</h2>
          <p className="text-gray-700 text-sm leading-relaxed">
            We build custom patio covers that extend your shade and protect
            from rain, so you can actually enjoy your backyard in Houston’s
            weather. We match rooflines, posts, and finishes to your home so
            it looks original — not added on.
          </p>
        </div>

        <div className="card">
          <h2 className="text-xl font-bold mb-2 text-gray-900">Pergolas</h2>
          <p className="text-gray-700 text-sm leading-relaxed">
            Our pergolas are built from high-quality lumber and designed for
            both looks and function. We can do open-top for filtered light or
            add shade panels for more coverage.
          </p>
        </div>

        <div className="card">
          <h2 className="text-xl font-bold mb-2 text-gray-900">Outdoor Kitchens</h2>
          <p className="text-gray-700 text-sm leading-relaxed">
            Full outdoor kitchen builds including stone or brick surrounds,
            countertop install, grill cutouts, storage, lighting, and more.
            Built for cooking, hosting, and adding value to your home.
          </p>
        </div>
      </div>
    </section>
  );
}
