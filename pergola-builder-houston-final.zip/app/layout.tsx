import "./globals.css";
import Header from "./components/Header";
import MobileCTA from "./components/MobileCTA";
import CityFooter from "./components/CityFooter";

export const metadata = {
  title: "Pergola Builder Houston | Custom Pergolas & Patio Covers",
  description:
    "Custom patio covers, pergolas, and outdoor kitchens built by Pergola Builder Houston. Your Local Pergola Experts in Houston, TX.",
  openGraph: {
    title: "Pergola Builder Houston | Custom Pergolas & Patio Covers",
    description:
      "Custom patio covers, pergolas, and outdoor kitchens built by Pergola Builder Houston. Your Local Pergola Experts in Houston, TX.",
    type: "website"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* Google Analytics placeholder - replace G-XXXXXXXXXX with your GA4 Measurement ID */}
        <script
          async
          src={"https://www.googletagmanager.com/gtag/js?id=" + "G-XXXXXXXXXX"}
        />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', 'G-XXXXXXXXXX');
            `
          }}
        />
        {/* Google Search Console verification placeholder */}
        <meta
          name="google-site-verification"
          content="SEARCH_CONSOLE_VERIFICATION_CODE"
        />
        <link rel="icon" href="/favicon.svg" />
        <meta name="robots" content="index, follow" />
      </head>
      <body className="bg-white text-gray-900">
        <Header />
        <main className="pt-20">{children}</main>
        <CityFooter />
        <MobileCTA />
      </body>
    </html>
  );
}
